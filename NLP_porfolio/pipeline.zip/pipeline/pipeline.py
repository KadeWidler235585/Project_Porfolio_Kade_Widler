"""
Group 21 — Students: Aryan, Michael, Kade
-----------------------------------------
Main pipeline that runs:
1. YouTube URL to .mp3 audio file
2. Transcription
3. Translation (EN→NL)
4. Round Translation (NL→EN)
5. Emotion Classification
"""

import os
from datetime import datetime
from youtube_to_audio import download_audio
from transcribe import transcribe_audio
from translation import add_translation_column
from round_translation import add_round_translation
from emotion_classification import add_emotion_column

def run_pipeline():

    import os

    print("Current working directory:", os.getcwd())

    # Step 1: YouTube → Audio
    print("\n--- STEP 1: YOUTUBE TO AUDIO ---")
    youtube_url = input("Enter YouTube URL: ").strip()
    base_name = input("Enter output filename (without .mp3): ").strip() or "audio"
    audio_path = download_audio(youtube_url, base_name)
    audio_path = os.path.abspath(audio_path)

    # Step 2: Transcription
    print("\n--- STEP 2: TRANSCRIPTION ---")
    transcription_path = transcribe_audio(audio_path)

    # Step 3: Translation (EN → NL)
    print("\n--- STEP 3: TRANSLATION ---")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    translated_path = os.path.join(
        os.path.expanduser("~"),
        "Downloads",
        f"translated_{timestamp}.xlsx"
    )
    add_translation_column(transcription_path, translated_path)

    # Step 4: Round Translation (NL → EN)
    print("\n--- STEP 4: ROUND TRANSLATION ---")
    round_translated_path = os.path.join(
        os.path.expanduser("~"),
        "Downloads",
        f"round_translated_{timestamp}.xlsx"
    )
    add_round_translation(translated_path, round_translated_path)

    # Step 5: (Optional) Emotion Classification
    print("\n--- STEP 5: EMOTION CLASSIFICATION ---")
    final_output_path = os.path.join(
        os.path.expanduser("~"),
        "Downloads",
        f"final_output_{timestamp}.xlsx"
    )
    add_emotion_column(round_translated_path, final_output_path)

    print("\n✅ PIPELINE COMPLETE!")
    print(f"Audio file:       {audio_path}")
    print(f"Transcription:   {transcription_path}")
    print(f"Translation:     {translated_path}")
    print(f"Round-Translation: {round_translated_path}")
    print(f"Emotion Classification: {final_output_path}")
if __name__ == "__main__":
    run_pipeline()