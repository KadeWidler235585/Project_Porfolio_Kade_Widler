"""
This module adds a 'Translation' column to the Excel
file produced by transcribe.py using a fine-tuned
Hugging Face MarianMT model (EN→NL).
"""

import os
import torch
import pandas as pd
from transformers import pipeline
from datetime import datetime

def add_translation_column(input_excel_path, output_excel_path, model_dir_en2nl="models/mt_ckpt_en2nl_here"):
    """
    Adds a 'Translation' column (EN→NL) to an Excel file.

    Parameters:
    - input_excel_path (str): Path to Excel file from transcribe.py
    - output_excel_path (str): Where to save the new file
    - model_dir_en2nl (str): Directory with fine-tuned EN→NL model
    """

    # Locate model directory
    if not os.path.exists(os.path.join(model_dir_en2nl, "config.json")):
        nested_dir = os.path.join(model_dir_en2nl, "mt_ckpt_en2nl")
        if os.path.exists(os.path.join(nested_dir, "config.json")):
            model_dir_en2nl = nested_dir
        else:
            raise FileNotFoundError(f"No model files found in {model_dir_en2nl} or {nested_dir}")

    print("Loading translation model (EN→NL)...")
    device = 0 if torch.cuda.is_available() else -1
    en2nl_pipeline = pipeline("translation", model=model_dir_en2nl, device=device)

    print(f"Reading Excel file: {input_excel_path}")
    input_excel_path = os.path.expanduser(input_excel_path.strip())
    df = pd.read_excel(input_excel_path)

    if "Sentence" not in df.columns:
        raise ValueError("Expected a column named 'Sentence' in the Excel file.")

    sentences = df["Sentence"].astype(str).tolist()
    translations = []

    print("Translating sentences...")
    batch_size = 16
    for i in range(0, len(sentences), batch_size):
        batch = sentences[i:i + batch_size]
        results = en2nl_pipeline(batch, truncation=True, max_length=128)
        translations.extend([r["translation_text"] for r in results])

    df["Translation"] = translations
    df.to_excel(output_excel_path, index=False)

    print(f"Saved translated Excel file to: {output_excel_path}")
    return output_excel_path

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

if __name__ == "__main__":
    # Example usage
    input_path = input("Enter path to transcription Excel file: ").strip('"')
    output_path = os.path.join(os.path.expanduser("~"), "Downloads", f"translated_{timestamp}.xlsx")

    add_translation_column(input_path, output_path)
