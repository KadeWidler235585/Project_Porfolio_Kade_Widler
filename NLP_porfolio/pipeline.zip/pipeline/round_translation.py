"""
This module adds a 'Round_Translation' column to the Excel
file produced by round_translation.py using a fine-tuned
Hugging Face MarianMT model (NL→EN).
"""

import os
import torch
import pandas as pd
from transformers import pipeline
from datetime import datetime

def add_round_translation(input_excel_path, output_excel_path, model_dir_nl2en="models/mt_ckpt_here"):
    
    # Locate model directory
    if not os.path.exists(os.path.join(model_dir_nl2en, "config.json")):
        nested_dir = os.path.join(model_dir_nl2en, "mt_ckpt")
        if os.path.exists(os.path.join(nested_dir, "config.json")):
            model_dir_nl2en = nested_dir
            print("MODEL FOUND")
        else:
            raise FileNotFoundError(f"No model files found in {model_dir_nl2en} or {nested_dir}")

    print("Loading round-translation model (NL→EN)...")
    device = 0 if torch.cuda.is_available() else -1
    nl2en_pipeline = pipeline("translation", model=model_dir_nl2en, device=device)

    print(f"Reading Excel file: {input_excel_path}")
    input_excel_path = os.path.expanduser(input_excel_path.strip())
    df = pd.read_excel(input_excel_path)

    if "Translation" not in df.columns:
        raise ValueError("Expected a column named 'Translation' (the Dutch text).")

    sentences = df["Translation"].astype(str).tolist()
    round_translations = []

    print("Performing round translation (NL→EN)...")
    batch_size = 16
    for i in range(0, len(sentences), batch_size):
        batch = sentences[i:i + batch_size]
        results = nl2en_pipeline(batch, truncation=True, max_length=128)
        round_translations.extend([r["translation_text"] for r in results])

    df["Round_Translation"] = round_translations
    df.to_excel(output_excel_path, index=False)

    print(f"Saved round-translated Excel file to: {output_excel_path}")
    return output_excel_path

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

if __name__ == "__main__":
    input_path = input("Enter path to translated Excel file: ").strip('"')
    output_path = os.path.join(os.path.expanduser("~"), "Downloads", f"round_translated_{timestamp}.xlsx")
    add_round_translation(input_path, output_path)
