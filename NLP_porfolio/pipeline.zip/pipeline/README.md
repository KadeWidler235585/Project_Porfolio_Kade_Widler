# Emotion Classification Pipeline (Group 21)

**Students:** Aryan, Michael, Kade  
**Group:** 21

This pipeline accepts a youtube URL and given file name outputting an .mp3 file,
transcribes the audio file using whisper outputting a timestamped Excel file with the columns "Sentence", "Start_time", and "End_time, 

then performs English→Dutch→English machine translation using fine-tuned MarianMT models adding "Translation" and "Round_Translation" columns to the timestamped Excel file,

and then finally a RoBerta Transformer model outputs a timestamped Excel file adding an "Emotions" column.

Classifications: [Ekman's six emotions](https://www.paulekman.com/wp-content/uploads/2013/07/Basic-Emotions.pdf) (happiness, fear, anger, sadness, surprise, disgust) + neutral.

The result is an Excel file with the columns "Start_time", "End_time", "Sentence", "Translation", "Round_Translation", and "Emotion".

# **Important instructions for making the emotion classification in the pipeline work**
After downloading the pipeline, please download the models:

1. **RoBERTa Emotion Model**  
[Download here](https://edubuas-my.sharepoint.com/:f:/g/personal/245086_buas_nl/ErYvmA-XgDZMhn5uVbX8H7YBJ9BrXaCea3xZJuJzE31uyQ?e=LVsFbv)  
Extract into: `pipeline/pipeline/models/roberta_emotion/`

2. **English→Dutch MarianMT Model**  
[Download here](https://edubuas-my.sharepoint.com/:f:/g/personal/245086_buas_nl/EricM86f0JNIunCZ4fSUg0YBSMEeMre4dT8AkZcI_IDuhA?e=xJnd5Y)  
Extract into: `pipeline/pipeline/models/mt_ckpt_en2nl_here/`

3. **Dutch→English MarianMT Model**  
[Download here](https://edubuas-my.sharepoint.com/:f:/g/personal/245086_buas_nl/ElWopyx6a6VFgBRONBPVMGAB_zFWMuljeXL3X2Nwfpjdqg?e=tVFwOO)  
Extract into: `pipeline/pipeline/models/mt_ckpt_here/`

```bash

pipeline/
├─ pipeline.py                # Main script to run the pipeline
├─ youtube_to_audio.py        # Youtube→Audio module
├─ transcribe.py              # Transcription module
├─ translation.py             # English→Dutch Translation module
├─ round_translation.py       # Dutch→English Translation module
├─ emotion_classification.py  # Emotion classification module
├─ models/
│   ├─ roberta_emotion/
│   │   └─ final_roberta_model/   <-- THE FINAL ROBERTA MODEL FOLDER 
│   ├─ mt_ckpt_here/
│   │   └─ mt_ckpt/               <-- THE FINAL Dutch→English MODEL FOLDER 
│   └─ mt_ckpt_en2nl_here/
│       └─ mt_ckpt_en2nl/         <-- THE FINAL English→Dutch MODEL FOLDER 
├─ requirements.txt
└─ requirements_macos_ONLY.txt

```

**## Please make sure you have `ffmpeg` installed**

Note: may have to install [brew](https://brew.sh/)

Type this into terminal/command prompt

```bash
ffmpeg -version
```

If you do not have ffmpeg installed then please install it either for **windows or macOS** [here](https://ffmpeg.org/download.html)

## **How to use pipeline:**

# For Windows:

1. Create a fresh virtual environment with python==3.11 (recommended)

2. Install into your virtual environment:
- requirements.txt file

```bash
pip install -r "C:\Users\<YOUR_USERNAME>\Downloads\pipeline\pipeline\requirements.txt"
```

3. Open pipeline.py file from folder in VS code

4. Once in VS code, in the VS code terminal enter:

```bash
cd "C:\Users\<YOUR_USERNAME>\Downloads\pipeline\pipeline"
```

Note: You need to make sure your current directory is this to access model files.

5. Enter youtube URL and you will receive your finished output containing:
- Start Time (per column)
- End Time (per column)
- Sentence (transcriptions)
- Translation (dutch translations)
- Round_Translation (translated back to english from dutch)
- Emotion

# For Mac:

1. Open Terminal

2. Create a fresh virtual environment with python==3.10 (recommended)
For example copy this code: conda create -n test_sentiment_pipeline python=3.10

3. When Prompted select "y" and press "enter"

4. Enter "cd pipeline" then enter "ls pipeline" to confirm you are in folder.

5. Install requirements file.
Other option: (you can copy path of requirements_macos_ONLY.txt by control clicking requirements_macos_ONLY.txt and selecting "copy path"):
For example: pip install -r /Users/"fill in"/Desktop/pipeline/pipeline/requirements_macos_ONLY.txt

6. Enter "python pipeline.py" and follow prompted instructions:
Enter full URL from desired video.
Enter desired name of .mp3 file.
Be patient (~takes 15 minutes for every 3 minutes of video)

Other uses: 

7. Enter "python" + name of any specific .py file to use.
For example, if you want to transcribe only use "python transcribe.py"
Note: MUST follow order of execution: transcribe to translation to round_translation to emotion classification.
Note: Can skip round_translation.

8. Additional, if you want to make classifications on the round_translated column:
In emotion_classification.py change line 53: sentences = df["Sentence"].astype(str).tolist()
To: sentences = df["Round_translation"].astype(str).tolist()


