"""
This module adds a 'Transcribe' column to the Excel
using Whisper.
"""
import whisper
import pandas as pd
import os
import torch
from datetime import datetime
import re

def format_time(seconds):
    """
    Creates formatting for time stamps.
    """
    ms = int((seconds % 1) * 1000)
    s = int(seconds) % 60
    m = (int(seconds) // 60) % 60
    h = int(seconds) // 3600
    return f"{h:02}:{m:02}:{s:02},{ms:03}"
        
def transcribe_audio(audio_file):
    """
    Loads Whisper model
    Trancribes Audio
    Iterates over trancribed audio in segments adding start and end time data.
    Outputs Excel file called trancribed_data_whisper.xlsx with Start_time, End_time, and transcribed sentence columns.
    """

    model = whisper.load_model("turbo")
    
    result = model.transcribe(audio_file)
    segments = result.get("segments", [])
    
    data = []

    for seg in segments:
        start_time = format_time(seg["start"])
        end_time = format_time(seg["end"])
        text = seg["text"].strip()

        # Split long text into sentences
        sentences = re.split(r'(?<=[.!?]) +', text)
        for sentence in sentences:
            sentence = sentence.strip()
            if sentence:
                data.append([start_time, end_time, text])

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"~/Downloads/transcribed_{timestamp}.xlsx"

    # Saving transcribed data in an Excel file in the Downloads folders
    df = pd.DataFrame(data, columns=["Start Time", "End Time", "Sentence"])
    df.to_excel(os.path.expanduser(output_file), index=False)
    
    print(f"Transcribed data saved to {output_file}")
    return os.path.expanduser(output_file)

# Asking for input
if __name__ == "__main__":
    audio_path = input("Copy and enter the FULL path to your audio file (include .mp3): ").strip().strip('"')
    transcribe_audio(audio_path)
