"""
This module adds an 'Emotion' column to the Excel
file produced by round_translation.py using a fine-tuned
Hugging Face RoBERTa model for emotion classification.

Machine Learning: Fine-tuned RoBERTa (text-classification)
"""

import os
import torch
import pandas as pd
from transformers import pipeline
from datetime import datetime

def add_emotion_column(input_excel_path, output_excel_path, model_dir="models/roberta_emotion"):
    """Adds an 'Emotion' column to an Excel file."""

    # Map LABEL_x → emotion
    label_map = {
        "LABEL_0": "happiness",
        "LABEL_1": "sadness",
        "LABEL_2": "anger",
        "LABEL_3": "surprise",
        "LABEL_4": "fear",
        "LABEL_5": "disgust",
        "LABEL_6": "neutral"
    }

    # Locate model directory
    if not os.path.exists(os.path.join(model_dir, "config.json")):
        nested_dir = os.path.join(model_dir, "final_roberta_model")
        if os.path.exists(os.path.join(nested_dir, "config.json")):
            model_dir = nested_dir
        else:
            raise FileNotFoundError(f"No model files found in {model_dir} or {nested_dir}")

    print("Loading emotion classification model...")
    device = 0 if torch.cuda.is_available() else -1

    emotion_pipe = pipeline(
        "text-classification",
        model=model_dir,
        tokenizer=model_dir,
        device=device
    )

    print(f"Reading Excel file: {input_excel_path}")
    df = pd.read_excel(input_excel_path)

    if "Sentence" not in df.columns:
        raise ValueError("Expected a column named 'Sentence' in the Excel file.")

    sentences = df["Sentence"].astype(str).tolist()
    emotions = []

    print("Classifying emotions...")
    batch_size = 16
    for i in range(0, len(sentences), batch_size):
        batch = sentences[i:i + batch_size]
        results = emotion_pipe(batch, truncation=True, max_length=128)
        for r in results:
            label = r["label"]
            mapped_label = label_map.get(label, label)  # map LABEL_x → readable emotion
            emotions.append(mapped_label)

    df["Emotion"] = emotions
    df.to_excel(output_excel_path, index=False)

    print(f"✅ Saved final emotion-classified Excel file to: {output_excel_path}")
    return output_excel_path

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

if __name__ == "__main__":
    input_path = input("Enter path to translated Excel file: ").strip('"')
    output_path = os.path.join(os.path.expanduser("~"), "Downloads", f"final_emotion_{timestamp}.xlsx")
    add_emotion_column(input_path, output_path)