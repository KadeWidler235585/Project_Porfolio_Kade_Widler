# youtube_to_audio.py
"""
This module takes a youtube url and desired file name 
input from the user and outputs .mp3 file.
"""

import yt_dlp

def download_audio(url, output_name="audio"):
    """Download audio from YouTube URL"""
    
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': f'{output_name}.%(ext)s',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
    }
    
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    
    print(f"Downloaded: {output_name}.mp3")
    return f"{output_name}.mp3"

if __name__ == "__main__":
    url = input("Enter YouTube URL: ").strip()
    name = input("Enter output filename (without .mp3): ").strip() or "audio"
    
    download_audio(url, name)